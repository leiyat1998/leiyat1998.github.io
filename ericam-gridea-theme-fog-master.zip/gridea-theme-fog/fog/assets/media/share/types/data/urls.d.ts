declare const _default: {
    qzone: string;
    qq: string;
    weibo: string;
    wechat: string;
    douban: string;
    linkedin: string;
    facebook: string;
    twitter: string;
    google: string;
};
export default _default;
