# 💖Gridea-theme-fog

<img src="https://ericamblog.oss-cn-shanghai.aliyuncs.com/2020/20201213.png">
<img src="https://ericamblog.oss-cn-shanghai.aliyuncs.com/2020/QQ%E5%9B%BE%E7%89%8720201213004926.png" width="40vw"><img src="https://ericamblog.oss-cn-shanghai.aliyuncs.com/2020/QQ%E5%9B%BE%E7%89%8720201213005107.png" width="40vw">

**最新版本：version_1.0**

主题介绍：[Gridea主题Fog](<https://ericam.top/post/gridea-zhu-ti-fog-geng-xin-ri-zhi/> )

主题Github下载地址：[github下载]（<https://github.com/850552586/gridea-theme-fog> ）

主题国内码云下载地址：（<https://gitee.com/ericam/gridea-theme-fog> ）

使用文档：[https://ericam.top/post/fog-zhu-ti-shi-yong-bang-zhu/](https://ericam.top/post/fog-zhu-ti-shi-yong-bang-zhu/)

主题更新日志：[https://ericam.top/post/fog-zhu-ti-geng-xin-ri-zhi/](https://ericam.top/post/fog-zhu-ti-geng-xin-ri-zhi/)

欢迎加入Fog主题交流群（可以分享你遇到的问题，或者咨询主题开发建议）
<img width="30vw" src="https://ericamblog.oss-cn-shanghai.aliyuncs.com/GrideaFog/qrcode_1594635464040.jpg">

**走过路过留个star⭐️可好？🤒😎**

## 为爱发电

如果你觉得主题好用，希望可以赞助该主题表示支持~

<img width="30vw" src="https://ericamblog.oss-cn-shanghai.aliyuncs.com/GrideaFog/mm_facetoface_collect_qrcode_1597384660504.png">


## 主题博客预览
这是已经使用上fog主题的小伙伴~(排名不分先后)



<a href="https://ericam.top/"><img src="https://ericam.top/images/avatar.png?v=1607787924196" width="100px" height="100px" style="border-radius:40%"></a><a href="https://hkjyh5.coding-pages.com/"><img src="https://hkjyh5.coding-pages.com/images/avatar.png?v=1607775007533" width="100px" height="100px" style="border-radius:40%"></a><a href="https://beimumu.top/"><img src="https://beimumu.top/images/avatar.png?v=1607069556599" width="100px" height="100px" style="border-radius:40%"></a><a href="https://codingbear.top/"><img src="https://codingbear.top/images/avatar.png?v=1605196379447" width="100px" height="100px" style="border-radius:40%"></a><a href="https://imon.eu.org/"><img src="https://imon.eu.org/images/avatar.png?v=1613524519610" width="100px" height="100px" style="border-radius:40%"></a>








